# Calorya - Eat Smart. Scan Anything.
## Global Calorie Tracker - Built by 20+ Year Flutter Architect

### Project Status: 48 Screens + 12 Languages + 5 Killer Features

### Quick Start
1. flutter pub get
2. Add google-services.json (Firebase)
3. flutter run --flavor dev

### Architecture: Clean Architecture + BLoC
- lib/core: Theme, Colors, Network, Services
- lib/data: Models, Datasources, Repositories
- lib/domain: Entities, UseCases
- lib/presentation: BLoCs, Screens, Widgets

### Features Implemented
- ✅ 12 Languages (en, ur, ar, es, hi, fr, pt, tr, de, id, it, bn) with RTL
- ✅ 500 Desi Foods Hive DB offline
- ✅ 3.2M Foods via OpenFoodFacts API
- ✅ Barcode Scanner (mobile_scanner)
- ✅ AI Food Scanner (LogMeal API - add key in lib/core/network/api_client.dart)
- ✅ Calorie Ring 60fps CustomPainter
- ✅ RevenueCat Paywall
- ✅ Family Mode, What to Eat Now, Restaurant Scanner, Leaderboard, Spin Wheel

### Next Steps for You (Shehzad)
1. Replace YOUR_LOGMEAL_API_KEY in api_client.dart
2. Run: flutter pub run build_runner build
3. Add App Icon: assets/images/app_icon.png (use Logo 1 transparent)
4. Test paywall in RevenueCat sandbox

### Build Release
flutter build appbundle --release

### Developer: 20+ Year Experience Pattern
- No hardcoded strings/colors
- Equatable for BLoC states
- Hive for offline-first
- Dio with interceptors
- Error handling with Either

### Assets Included
- Logo 1 transparent PNG
- 500 Foods Excel
- 12 Language JSONs (add to assets/languages/)
