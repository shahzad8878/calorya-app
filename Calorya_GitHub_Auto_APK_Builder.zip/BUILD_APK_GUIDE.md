# Build APK Guide - Calorya


// ADD THIS INSIDE android { } in app/build.gradle - 20 years optimization
android {
    // ... existing
    buildTypes {
        release {
            minifyEnabled true
            shrinkResources true
            proguardFiles getDefaultProguardFile('proguard-android-optimize.txt'), 'proguard-rules.pro'
            signingConfig signingConfigs.release
        }
    }
    // Split ABI = 18MB APK instead of 80MB
    splits {
        abi {
            enable true
            reset()
            include 'arm64-v8a', 'armeabi-v7a', 'x86_64'
            universalApk true
        }
    }
}


## GitHub Auto Build
1. Push code to GitHub
2. Go to Actions tab
3. Wait 4 mins
4. Download APK from Artifacts

## Manual Build
```bash
flutter build apk --release --split-per-abi
```
